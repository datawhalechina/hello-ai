
(function () {
  "use strict";
  /* ============ 数据模型 ============
     Task: { id, title, quadrant, due (ISO str|null), done, created, order }
     quadrant: q1 重要且紧急 / q2 重要不紧急 / q3 紧急不重要 / q4 不重要不紧急
     参考 GSD Task Manager 的四象限模型 + Duet 的四种任务状态（未开始/进行/到期/过期 简化为到期态展示）
  */
  var STORE_KEY = "suzy2027.tasks.v1";
  var JOURNAL_KEY = "suzy2027.journal.v1";
  var GOALS_KEY = "suzy2027.goals.v1";

  var QUADS = [
    { id: "q1", name: "重要且紧急", en: "Do First", color: "var(--q1)", hex: "#8FA5B8" },
    { id: "q2", name: "重要不紧急", en: "Schedule", color: "var(--q2)", hex: "#9BB5A2" },
    { id: "q3", name: "紧急不重要", en: "Delegate", color: "var(--q3)", hex: "#C9A3A8" },
    { id: "q4", name: "不重要不紧急", en: "Later", color: "var(--q4)", hex: "#C9B98F" }
  ];
  var quadMap = {};
  QUADS.forEach(function (q) { quadMap[q.id] = q; });

  function uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }
  function load(key, fallback) {
    try { var v = JSON.parse(localStorage.getItem(key)); return v || fallback; }
    catch (e) { return fallback; }
  }
  function save(key, v) { localStorage.setItem(key, JSON.stringify(v)); }

  var tasks = load(STORE_KEY, []);
  var journals = load(JOURNAL_KEY, []);   // [{id, date, text}]
  var goals = load(GOALS_KEY, []);        // [{id, text, done}]

  function saveTasks() { save(STORE_KEY, tasks); }

  /* ============ 工具 ============ */
  var $ = function (s) { return document.querySelector(s); };
  function esc(s) {
    return s.replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function todayStr() {
    var d = new Date(); return d.getFullYear() + "-" + String(d.getMonth()+1).padStart(2,"0") + "-" + String(d.getDate()).padStart(2,"0");
  }
  function dueInfo(due) {
    if (!due) return null;
    var today = todayStr();
    if (due < today) return { cls: "overdue", label: "已过期 " + due.slice(5) };
    if (due === today) return { cls: "today", label: "今天到期" };
    var diff = Math.round((new Date(due) - new Date(today)) / 86400000);
    if (diff <= 3) return { cls: "warn", label: diff + " 天后 · " + due.slice(5) };
    return { cls: "", label: due.slice(5) };
  }

  /* ============ 四象限渲染 ============ */
  var grid = $("#quad-grid");
  QUADS.forEach(function (q) {
    var el = document.createElement("div");
    el.className = "quad";
    el.style.setProperty("--accent", q.color);
    el.dataset.quad = q.id;
    el.innerHTML =
      '<div class="quad-head"><div class="quad-name">' + q.name + '<span class="en">' + q.en + '</span></div>' +
      '<div class="quad-count" data-count>0</div></div>' +
      '<div class="task-list" data-list></div>' +
      '<input class="quick-add" data-add placeholder="输入任务，回车添加" data-quad="' + q.id + '">';
    grid.appendChild(el);
  });

  function sortTasks(a, b) {
    if (a.done !== b.done) return a.done ? 1 : -1;
    if (a.due && b.due && a.due !== b.due) return a.due < b.due ? -1 : 1;
    if (a.due && !b.due) return -1;
    if (!a.due && b.due) return 1;
    return (a.order || 0) - (b.order || 0);
  }

  function renderQuad() {
    QUADS.forEach(function (q) {
      var panel = grid.querySelector('[data-quad-panel="' + q.id + '"]') || grid.querySelector('.quad[data-quad="' + q.id + '"]');
      var list = panel.querySelector("[data-list]");
      var count = panel.querySelector("[data-count]");
      var items = tasks.filter(function (t) { return t.quadrant === q.id; }).sort(sortTasks);
      count.textContent = items.length;
      list.innerHTML = "";
      if (!items.length) {
        list.innerHTML = '<div class="empty-hint">暂无任务</div>';
      }
      items.forEach(function (t) { list.appendChild(buildTaskEl(t)); });
    });
    $("#nav-count-tasks").textContent = tasks.filter(function(t){return !t.done;}).length;
  }

  function buildTaskEl(t) {
    var el = document.createElement("div");
    el.className = "task" + (t.done ? " done" : "");
    el.draggable = true;
    el.dataset.id = t.id;
    var di = dueInfo(t.due);
    el.innerHTML =
      '<span class="task-handle" title="拖动">' +
        '<svg width="8" height="14" viewBox="0 0 8 14" fill="currentColor"><circle cx="2" cy="2" r="1.4"/><circle cx="6" cy="2" r="1.4"/><circle cx="2" cy="7" r="1.4"/><circle cx="6" cy="7" r="1.4"/><circle cx="2" cy="12" r="1.4"/><circle cx="6" cy="12" r="1.4"/></svg>' +
      "</span>" +
      '<span class="task-check" title="完成/取消"></span>' +
      '<span class="task-name">' + esc(t.title) + "</span>" +
      (di ? '<span class="task-due ' + di.cls + '" title="点击修改截止日期">' + di.label + "</span>" : '<span class="task-due" title="设置截止日期">＋日期</span>') +
      '<button class="task-del" title="删除">×</button>';

    el.querySelector(".task-check").addEventListener("click", function (e) {
      e.stopPropagation();
      t.done = !t.done; saveTasks(); renderAll();
    });
    el.querySelector(".task-due").addEventListener("click", function (e) {
      e.stopPropagation(); openDuePop(e.target, t);
    });
    el.querySelector(".task-del").addEventListener("click", function (e) {
      e.stopPropagation();
      tasks = tasks.filter(function (x) { return x.id !== t.id; });
      saveTasks(); renderAll(); showToast("已删除");
    });

    /* 拖拽 */
    el.addEventListener("dragstart", function (e) {
      e.dataTransfer.setData("text/plain", t.id);
      e.dataTransfer.effectAllowed = "move";
      requestAnimationFrame(function () { el.classList.add("dragging"); });
    });
    el.addEventListener("dragend", function () { el.classList.remove("dragging"); });
    return el;
  }

  /* 象限：拖入放置 + 输入添加 */
  grid.querySelectorAll(".quad").forEach(function (panel) {
    panel.addEventListener("dragover", function (e) {
      e.preventDefault(); panel.classList.add("drag-over");
    });
    panel.addEventListener("dragleave", function (e) {
      if (!panel.contains(e.relatedTarget)) panel.classList.remove("drag-over");
    });
    panel.addEventListener("drop", function (e) {
      e.preventDefault(); panel.classList.remove("drag-over");
      var id = e.dataTransfer.getData("text/plain");
      var t = tasks.find(function (x) { return x.id === id; });
      if (t && t.quadrant !== panel.dataset.quad) {
        t.quadrant = panel.dataset.quad; saveTasks(); renderAll();
      }
    });
  });
  grid.querySelectorAll("[data-add]").forEach(function (inp) {
    inp.addEventListener("keydown", function (e) {
      if (e.key !== "Enter" || !inp.value.trim()) return;
      var maxOrder = tasks.reduce(function (m, t) { return Math.max(m, t.order || 0); }, 0);
      tasks.push({
        id: uid(), title: inp.value.trim(), quadrant: inp.dataset.quad,
        due: null, done: false, created: new Date().toISOString(), order: maxOrder + 1
      });
      inp.value = ""; saveTasks(); renderAll();
    });
  });

  /* 日期 popover（Zebar 式轻量浮层交互） */
  function openDuePop(anchor, task) {
    closeDuePop();
    var pop = document.createElement("div");
    pop.className = "due-pop";
    pop.innerHTML =
      '<div style="font-size:11px;color:var(--text-sub);margin-bottom:8px;">截止日期</div>' +
      '<input type="date" value="' + (task.due || "") + '">' +
      '<div class="pop-row">' +
        '<button class="pop-btn pop-clear">清除</button>' +
        '<button class="pop-btn pop-ok">确定</button>' +
      "</div>";
    document.body.appendChild(pop);
    var r = anchor.getBoundingClientRect();
    pop.style.top = Math.min(window.innerHeight - pop.offsetHeight - 10, r.bottom + 6) + "px";
    pop.style.left = Math.max(8, Math.min(window.innerWidth - pop.offsetWidth - 10, r.left - 60)) + "px";
    var input = pop.querySelector("input");
    pop.querySelector(".pop-ok").addEventListener("click", function () {
      task.due = input.value || null; saveTasks(); closeDuePop(); renderAll();
      if (input.value === todayStr()) showToast("今天到期，留意一下");
    });
    pop.querySelector(".pop-clear").addEventListener("click", function () {
      task.due = null; saveTasks(); closeDuePop(); renderAll();
    });
    setTimeout(function () {
      document.addEventListener("mousedown", popOutside);
    }, 0);
    function popOutside(e) { if (!pop.contains(e.target)) closeDuePop(); }
    currentPop = pop; currentPopHandler = popOutside;
  }
  var currentPop = null, currentPopHandler = null;
  function closeDuePop() {
    if (currentPop) {
      document.removeEventListener("mousedown", currentPopHandler);
      currentPop.remove(); currentPop = null;
    }
  }

  /* ============ 今日聚焦 ============ */
  function renderFocus() {
    var list = $("#focus-list");
    var today = todayStr();
    var weekLater = new Date(Date.now() + 7 * 86400000).toISOString().slice(0, 10);
    var items = tasks
      .filter(function (t) { return !t.done && t.due && t.due <= weekLater; })
      .sort(function (a, b) { return a.due < b.due ? -1 : 1; });
    $("#nav-count-focus").textContent = items.filter(function(t){return t.due <= today;}).length;
    list.innerHTML = "";
    if (!items.length) { list.innerHTML = '<div class="empty-hint">未来 7 天没有到期任务，享受此刻 🌊</div>'; return; }
    items.forEach(function (t) {
      var q = quadMap[t.quadrant];
      var div = document.createElement("div");
      div.className = "focus-item";
      var di = dueInfo(t.due);
      div.innerHTML =
        '<span class="fq-tag" style="background:' + q.hex + '">' + q.name + "</span>" +
        '<span style="flex:1">' + esc(t.title) + "</span>" +
        '<span class="fdate" style="' + (di && di.cls === "overdue" ? "color:#A8402F" : di && di.cls === "today" ? "color:#C2704F" : "") + '">' + di.label + "</span>";
      list.appendChild(div);
    });
  }

  /* ============ 每日一记 ============ */
  function renderJournal() {
    var list = $("#journal-list");
    list.innerHTML = "";
    if (!journals.length) { list.innerHTML = '<div class="empty-hint" style="padding:6px 0;">还没有记录</div>'; return; }
    journals.slice().sort(function (a, b) { return a.date < b.date ? 1 : -1; }).forEach(function (j) {
      var div = document.createElement("div");
      div.className = "journal-entry";
      div.innerHTML = '<span class="j-del" title="删除">删除</span><div class="j-date">' + j.date + "</div>" + esc(j.text).replace(/\n/g, "<br>");
      div.querySelector(".j-del").addEventListener("click", function () {
        journals = journals.filter(function (x) { return x.id !== j.id; });
        save(JOURNAL_KEY, journals); renderJournal();
      });
      list.appendChild(div);
    });
  }
  $("#journal-save").addEventListener("click", function () {
    var text = $("#journal-input").value.trim();
    if (!text) { showToast("写点什么再保存吧"); return; }
    journals.push({ id: uid(), date: todayStr(), text: text });
    save(JOURNAL_KEY, journals);
    $("#journal-input").value = "";
    renderJournal(); showToast("已保存 ✓");
  });

  /* ============ 年度目标 ============ */
  function renderGoals() {
    var list = $("#goals-list");
    list.innerHTML = "";
    if (!goals.length) { list.innerHTML = '<div class="empty-hint" style="padding:6px 0;">添加你的第一个年度目标</div>'; return; }
    goals.forEach(function (g) {
      var div = document.createElement("div");
      div.className = "goal-item" + (g.done ? " done" : "");
      div.innerHTML = '<span class="goal-check"></span><span class="goal-text">' + esc(g.text) + '</span><span class="task-del">×</span>';
      div.querySelector(".goal-check").addEventListener("click", function () {
        g.done = !g.done; save(GOALS_KEY, goals); renderGoals();
      });
      div.querySelector(".task-del").addEventListener("click", function () {
        goals = goals.filter(function (x) { return x.id !== g.id; });
        save(GOALS_KEY, goals); renderGoals();
      });
      list.appendChild(div);
    });
  }
  $("#goal-input").addEventListener("keydown", function (e) {
    if (e.key !== "Enter" || !e.target.value.trim()) return;
    goals.push({ id: uid(), text: e.target.value.trim(), done: false });
    save(GOALS_KEY, goals);
    e.target.value = ""; renderGoals();
  });

  /* ============ 统计 ============ */
  function renderStats() {
    var total = tasks.length;
    var done = tasks.filter(function (t) { return t.done; }).length;
    var overdue = tasks.filter(function (t) { return !t.done && t.due && t.due < todayStr(); }).length;
    var week = tasks.filter(function (t) { return !t.done && t.due && t.due <= new Date(Date.now() + 7*86400000).toISOString().slice(0,10); }).length;
    var goalsDone = goals.filter(function (g) { return g.done; }).length;
    var stats = [
      { num: tasks.filter(function(t){return !t.done;}).length, label: "待办任务" },
      { num: done, label: "已完成" },
      { num: overdue, label: "已过期" },
      { num: week, label: "本周内到期" },
      { num: goalsDone + " / " + goals.length, label: "年度目标" },
      { num: journals.length, label: "一记条数" }
    ];
    var row = $("#stat-row"); row.innerHTML = "";
    stats.forEach(function (s) {
      var d = document.createElement("div");
      d.className = "stat-card";
      d.innerHTML = '<div class="stat-num">' + s.num + '</div><div class="stat-label">' + s.label + "</div>";
      row.appendChild(d);
    });
  }

  /* ============ 导航 ============ */
  document.querySelectorAll(".nav-item").forEach(function (item) {
    item.addEventListener("click", function () {
      document.querySelectorAll(".nav-item").forEach(function (i) { i.classList.remove("active"); });
      item.classList.add("active");
      ["quad", "focus", "journal", "goals", "stats"].forEach(function (v) {
        $("#view-" + v).classList.toggle("hidden", v !== item.dataset.view);
      });
      closeDuePop();
    });
  });

  /* ============ Toast ============ */
  var toastTimer = null;
  function showToast(msg) {
    var t = $("#toast");
    t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("show"); }, 1600);
  }

  function renderAll() {
    renderQuad(); renderFocus(); renderStats();
    if (!$("#view-journal").classList.contains("hidden")) renderJournal();
    if (!$("#view-goals").classList.contains("hidden")) renderGoals();
  }

  /* 示例数据（首次打开） */
  if (!localStorage.getItem(STORE_KEY)) {
    tasks = [
      { id: uid(), title: "回复重要客户邮件", quadrant: "q1", due: todayStr(), done: false, created: new Date().toISOString(), order: 1 },
      { id: uid(), title: "准备 2027 个人年度计划", quadrant: "q2", due: null, done: false, created: new Date().toISOString(), order: 2 },
      { id: uid(), title: "整理本周报销单据", quadrant: "q3", due: null, done: false, created: new Date().toISOString(), order: 3 }
    ];
    saveTasks();
  }

  renderAll();
})();
