# 🚀 Hello-Agents 又上新了!视频课开录、第五章低代码实战「四平台」全齐

Datawhale 开源智能体教程 **Hello-Agents《从零开始构建智能体》** 最近又更新了!快来一起看看有什么新的内容加入！

---

## 📊 近期更新一览

| 模块 | 更新内容 | 说明 |
| --- | --- | --- |
| 🎬 视频课程 | 新增「视频课录制共创」专栏(Extra13) | 第四章 ReAct 等范式视频已上线,更多章节持续放出 |
| 🧩 第五章 低代码平台 | 从 3 平台扩展到 **4 平台** | 新增 **FastGPT** 全章节,Coze、Dify 案例升级 |
| 💻 配套代码 | 新增 FastGPT / Coze 案例,更新 Dify 工作流 | 可直接导入复现,边读边练 |
| 📂 社区贡献精选 | Extra-Chapter 多篇实战干货 | Agent 自进化、WebAgent、旅行助手后训练等(见下文) |
| 🌏 中英双语 | 中英文文档 + 导航同步更新 | 海内外读者一致体验 |
| 🤝 社区 | 新增多位内容贡献者 | 开放共创,欢迎你也来 |

---

## 🎬 重点一:视频课开录了!而且这是一次「开放共创」

很多同学反馈,光看文字教程,有些关键章节还是希望"有人手把手讲一遍"。这次,Hello-Agents 正式推进**配套视频课录制**,目标是把教程里的关键章节讲得更直观、更容易上手。

新增的 **Extra13「Hello-Agents 视频课录制共创」** 专栏里,有一份持续更新的**视频课程导航**:

- ✅ **已上线**:第四章「智能体经典范式构建」——手把手实现 **ReAct、Plan-and-Solve、Reflection**(制作人:范丽,视频已发布到小红书)
- 🔜 **录制中 / 待发布**:第五章低代码平台、第六章 LangGraph、第九章上下文工程、第十四章 DeepResearch、附录二上下文工程补充……

更重要的是,**这是一场开放共创**。视频课不打算由少数人闭门完成,而是希望由更多学习者一起来讲:

> 你愿意把自己对某一章、某一节的理解讲出来,就能参与录制,把学习过程沉淀成帮助后来者的公开资料。

**参与你能收获什么?**

1. 🧠 深度践行**费曼学习法**,真正把知识讲透、学扎实;
2. 🤝 参与开源社区建设,结识一群志同道合的伙伴;
3. 🎥 学会制作教学讲解视频这项硬技能;
4. 🌟 优秀讲解将**直接纳入课程**,上传至小红书与 GitHub,**成为项目贡献者、可写进简历**;
5. 🎁 有机会获得 Datawhale 精美文创周边。

项目还贴心地放出了**"打样"示例视频**和**在线提交表**,不知道怎么录、风格怎么把控的同学,可以先参考示例再上手。录制的过程本身,就是一次极好的复盘——你会重新梳理章节脉络、补齐代码实践细节。

---

## 🧩 重点二:第五章「低代码平台」大改版,四大平台一次讲透

第五章「基于低代码平台的智能体搭建」,是很多零基础同学动手做出第一个 Agent 的地方。本周这一章迎来由社区贡献者 **黄佩林(HeteroCat)** 主导的大幅升级——平台从 3 个扩展到 **4 个**,并配齐了可复现的实战案例:

### 🆕 全新加入:平台三 FastGPT —— 知识库问答的极致优化

新增的 **5.4 FastGPT** 是本次更新的最大亮点。FastGPT 是一个开源的、基于大语言模型的**知识库问答平台与 Agent 构建工具**,定位"企业级 AI 生产力引擎",把"数据导入—智能分块—向量检索—对话生成"这条完整 RAG 链路做到了极致。

本节带你完整走一遍:
- 平台介绍与核心功能(免费版套餐、知识库管理、分块参数配置、**原生 MCP 工具**支持);
- 📈 实战案例 **「智能投顾助手」**:结合知识库 + MCP 工具 + 工作流编排,实现回答金融投资理论问题、**查询实时股票行情**、用户风险画像评估,并生成**个性化投资策略报告**;
- FastGPT 的优势与局限分析。

### 🔧 同步升级:Coze 与 Dify 案例焕新

- **平台一 Coze**:案例升级为 **「每日 AI 简报」助手**,自动汇总 AI 技术新闻、学术论文与开源项目,配套案例文件可一键导入;
- **平台二 Dify**:**「超级智能体个人助手」** 案例大幅扩充,新增**图片 / 视频生成**实战(接入即梦插件,调用 seedream / seedance 最新模型),并补充了**循环、参数获取、条件判断**等进阶工作流玩法;
- **平台四 n8n**:工作流自动化 + AI 能力集成,搭建智能邮件助手与私有知识库 Agent。

四个平台覆盖**零代码体验(Coze)→ 全栈开发(Dify)→ 知识库问答(FastGPT)→ 流程自动化(n8n)**,各有侧重,读完你就能根据自己的需求选对工具、跑通案例。

> 📦 配套代码也已同步:新增 `HelloAgent_fastgptCase.json`、`HelloAgent_cozeCase.zip`,更新 `HelloAgent_difyCase.yml`,全部在仓库 `code/chapter5/` 下,导入即可复现。

---

## 📂 别错过:社区贡献精选(Extra-Chapter)必读清单

除了正文章节,Hello-Agents 还有一个由社区共创的 **Extra-Chapter「社区贡献精选」**,沉淀大家在 Agent 实战中的独到经验。下面这几篇尤其值得一读,每一篇都能单独拿来啃:

| 章节 | 内容速览 | 直达链接 |
| --- | --- | --- |
| 💡 Extra09 · Agent 应用开发踩坑 | Code Agent 应用开发的踩坑与经验总结 | https://github.com/datawhalechina/hello-agents/blob/main/Extra-Chapter/Extra09-Agent应用开发实践踩坑与经验分享.md |
| 🛠️ Extra10 · Agent 自进化 | Agent 自进化的四类闭环机制与代表项目 | https://github.com/datawhalechina/hello-agents/blob/main/Extra-Chapter/Extra10-Agent自进化.md |
| 🌐 Extra11 · WebAgent 科普与实战 | Web Agent 原理、反爬实战与 HelloAgents 集成 | https://github.com/datawhalechina/hello-agents/blob/main/Extra-Chapter/Extra11-WebAgent科普与实战.md |
| ✈️ Extra12 · 旅行助手后训练实战 | 把旅行助手 Demo 打磨成真正能用的 Planner | https://github.com/datawhalechina/hello-agents/blob/main/Extra-Chapter/Extra12-旅行助手后训练实战.md |
| 🎬 Extra13 · 视频课录制共创 | 视频课程共创录制资源(详见上文) | https://github.com/datawhalechina/hello-agents/blob/main/Extra-Chapter/Extra13-Hello-Agents视频课录制共创.md |

> 这些都来自社区贡献者的真实实践。如果你也有踩坑总结或独到见解,欢迎以 PR 形式投稿到 Extra-Chapter,期待你的第一次贡献!

---

## 🔗 如何开始学习

- 🌐 **在线阅读(国内加速)**:https://hello-agents.datawhale.cc
- 🌍 **在线阅读(海外)**:https://datawhalechina.github.io/hello-agents/
- ⭐ **GitHub 仓库**(欢迎 Star / Fork / 提 Issue):https://github.com/datawhalechina/hello-agents
- 📕 **PDF 下载**:GitHub Releases 或 Datawhale 官网 https://www.datawhale.cn/learn/summary/239

---

## 🙌 一起来共创

Hello-Agents 是一个开放的开源社区项目,它的每一次更新,都来自像你一样的学习者与贡献者:

- 🐛 发现内容或代码问题 → 提 **Issue**
- 📝 想完善教程 → 提 **Pull Request**
- 🎬 想讲一节课 → 参与 **视频课共创**(见 Extra13)
- ✍️ 想分享实践 → 投稿到 **Extra-Chapter / 社区贡献精选**

如果这本教程对你有帮助,别忘了去 GitHub 给项目点一个 ⭐ **Star**,和更多同学一起把 Hello-Agents 学透、用起来。

---

## 🌟 来 GitHub 一起共建,也欢迎立项你自己的项目

Hello-Agents 只是 Datawhale 开源版图里的一块。如果你也想动手,非常欢迎来 GitHub:

- 🛠️ **参与项目贡献** — 给 Hello-Agents 提 Issue、提 PR、投稿 Extra-Chapter,从你的第一次贡献开始;
- 🚀 **立项你自己的开源项目** — 有好的学习项目想法?欢迎在 Datawhale 立项,把它做成下一个帮助万千学习者的开源教程。

下面几个智能体 / 大模型相关的开源项目,同样值得一看,也欢迎一起共建:

| 项目 | 简介 | 直达链接 |
| --- | --- | --- |
| 🤖 HelloAgents 框架 | Hello-Agents 配套自研智能体框架,已发布 V1.0.0 | https://github.com/jjyaoao/helloagents |
| 🐫 handy-multi-agent | 基于 CAMEL 框架的多智能体实战教程 | https://github.com/datawhalechina/handy-multi-agent |
| 🎓 diy-llm | 系统性大语言模型构建课程,代码驱动搭建 LLM 全栈认知 | https://github.com/datawhalechina/diy-llm |

> 🤖 关注 Datawhale,获取更多优质开源学习内容。让我们一起,从大模型的"使用者",成长为智能体时代的"构建者"。
