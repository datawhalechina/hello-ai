# Agent 总是 demo 能跑、真任务就崩？这门开源课带你搭出“能干长活”的 Deep Agent

![Deep Agents 实战 · 中文开源课](deepagent-imgs/hero.png)

> “用框架搭个 Agent”已经不难，难的是让它在真实任务里**稳稳跑完一长串步骤**——会规划、会管上下文、会调工具、会派子任务，出错还能被人接管。这正是 **Deep Agents**（LangChain 官方开源的“智能体运行骨架”）要解决的问题。开源课程 **《Deep Agents 实战》** 把它从认知讲到实战，带你亲手把它拆开、搭起来。课程讲什么、怎么参与，这篇一次说清 👇

---

**《Deep Agents 实战》** 是一门面向中文开发者的开源课，基于 LangChain / LangGraph 生态，带你从零构建**生产级 AI Agent**，由 [沧海九粟](https://space.bilibili.com/28357052) 发起并持续更新。下面就从“为什么做这门课”、“Deep Agents 到底是什么”、“课程里有什么”，一直聊到“想上手该怎么参与”👇

> 🔗 课程网站：https://datawhalechina.github.io/deepagents-in-action/
> ⭐ GitHub：https://github.com/datawhalechina/deepagents-in-action
> 📺 配套视频：https://space.bilibili.com/28357052/lists/7757577?type=season

## 💡 为什么做这门课

这门课是作者 “LangChain 生态实战” 系列的**第三部作品**。

前两部——[《LangChain 实战》](https://item.jd.com/14523254.html)和[《LangGraph 实战》](https://item.jd.com/10170803305693.html)——都以纸质书的形式出版。但写书的这两年暴露了一个矛盾：框架迭代太快，书一旦付印，版本就被时间钉死了；读者最常反馈的两类问题，一是“代码跑不通了”，二是“能不能再深入、再及时一点”——而纸质书的篇幅和周期，注定追不上这个几乎每个月都在变的领域。

于是到了第三部、主题更新更猛的 Deep Agents，作者换了打法：**不做成书，而是做成一门持续更新的开源课。** 因为开源课能做到纸质书做不到的事：

- **跟得上版本** — 框架更新了，课程就跟着更新，而不是停在某个印刷的瞬间；
- **真正可动手** — 每章配可运行示例、配套视频与讲义 PDF，代码错了能随时改、随时修；
- **和读者一起长大** — 每一条勘误、每一个 PR、每一次提问，都会沉淀回课程本身，让它越来越好。

课程想讲透的，是过去两年一个越来越明显的落差：“用框架搭个 Agent”已经不难——难的是让 Agent 在真实任务里**稳定地跑完一长串步骤**：会规划、会管理上下文、会调工具、会委派子任务、出错了还能被人接管。这正是 **Agent Harness（智能体运行骨架）** 要解决的问题，也是 Deep Agents 的设计内核。而中文世界里成体系、可动手、又对齐最新版本的实战教程还很少，这门课想补上的正是这块。

## 🧩 先说清楚：Deep Agents 到底是什么

可能不少读者还没接触过 Deep Agents，先用一段话讲清楚。

**Deep Agents 是 LangChain 官方开源的“智能体运行骨架（Agent Harness）”——一个开箱即用、内置了一整套最佳实践的 Agent。** 它不是“又一个调用大模型的框架”，而是建在 LangChain `create_agent` 与 LangGraph 运行时之上的更高一层封装。它的灵感直接来自 Claude Code——用官方的话说，是**“提炼出究竟是什么让 Claude Code 这类工具如此通用，再把它往前推一步”**。

> 一句话记住它：**Deep Agents ≈ 大模型 + 任务规划 + 子智能体 + 虚拟文件系统 + 精心设计的系统提示词。**

![Deep Agents 三层架构：Harness 建在 LangChain（Framework）与 LangGraph（Runtime）之上](deepagent-imgs/01-framework-three-layer-architecture.png)

它要解决的痛点很具体：让 Agent 在**长周期、多步骤的真实任务**里稳定跑完，而不是“demo 里跑通、真任务里就崩”。为此，它把一个能干长活的 Agent 该有的零件都打包好了：

- **🧠 任务规划** — 把复杂任务拆成步骤、跟踪进度、边做边调；
- **📁 虚拟文件系统** — 读写 / 编辑 / 搜索文件，用来放系统提示、技能与长期记忆，后端可换（本地或远程沙箱）；
- **🤝 子智能体** — 把独立子任务委派出去，各自隔离上下文，主线不被“撑爆”；
- **🗜️ 上下文管理** — 自动压缩历史、卸载超大工具结果、prompt 缓存，既省钱又提速；
- **🛠️ 技能与工具** — 可复用的能力包，加上自定义函数 / MCP 接入；
- **👮 人类接管 & 沙箱** — 关键操作可由人审批拦截，命令在 Shell 沙箱里执行，还能跨会话记忆。

而且它**模型无关**，Claude、GPT、Qwen 都能换着用；LangChain 把它的主战场总结为三类——**深度研究、写代码、多步骤工作流**。如今那些“会自己查资料写报告、会自己改代码”的强力 Agent，背后多半就是这类骨架在支撑。

把这些能力一个个拆开、带你亲手实现，正是这门课要做的事 👇

## 📚 课程包含什么

课程按“认知 → 核心 → 进阶 → 实战”循序展开，正文已发布 **8 章**（外加准备篇 2 讲），后续持续更新：

- **准备篇** — 用 AgentSeek CLI 快速搭建模板应用、安装开发辅助技能
- **认知篇** — 从 Agent Framework 到 Agent Harness 的诞生逻辑；5 分钟构建第一个 Deep Agent
- **核心篇** — 虚拟文件系统（Context Engineering 核心）、任务规划与分解、子 Agent 与上下文隔离、异步子 Agent
- **进阶篇** — Skills 可复用能力包、长期记忆；（规划中）Human-in-the-Loop、沙箱执行
- **实战篇**（规划中）— 实时流式前端、数据分析 Agent、CLI 与生产部署，并基于 [AgentSeek](https://github.com/ob-labs/agentseek) 提供可直接上手的应用模板

配套资源：可运行示例代码、每章讲义 PDF、[B 站视频合集](https://space.bilibili.com/28357052/lists/7757577?type=season)、[小红书图文](https://www.xiaohongshu.com/collection/item/69c4fd2a0072000000000001)。课程模型算力由 [硅基流动（SiliconFlow）](https://cloud.siliconflow.cn/i/Fq9zUwPf) 支持，平台模型种类比较全，还提供免费的文本模型与向量（Embedding）模型，方便大家低门槛地跟着课程做实验。

## 👥 适合谁

- 想系统学习 AI Agent 开发、不满足于“调通一个 demo”的开发者；
- 已经在用 LangChain / LangGraph，想进一步掌握 Deep Agents 工程实践的工程师；
- 零基础但有学习热情的同学——跟着章节顺序走就行。

## 🧭 怎么参与社区项目

这是一个**开放、持续更新**的社区项目，参与方式从“零成本跟学”到“深度共建”分了几档，按需上车就好：

**① 跟学 + Star（零成本起步）** — 打开[课程网站](https://datawhalechina.github.io/deepagents-in-action/)按章节走，觉得有用就去 [GitHub 仓库](https://github.com/datawhalechina/deepagents-in-action)点个 ⭐。Star 是对开源项目最直接的支持，也方便随时回来追更新。

**② 反馈问题：提 [Issue](https://github.com/datawhalechina/deepagents-in-action/issues/new/choose)** — 遇到“具体、可处理”的问题就开 Issue，各归其位、互相帮得上忙：
- 📝 **内容勘误** — 正文有错别字、表述不清、技术描述有误
- 🐛 **代码 / 环境问题** — 示例代码报错、依赖装不上、本地跑不起来
- 💡 **内容 / 改进建议** — 希望补充某个主题、调整讲法
- 🌐 **网站问题** — 排版错乱、链接失效、图片加载不出
  > 网站样式看起来不对？多半是浏览器缓存，先按 `Cmd/Ctrl + Shift + R` 强刷一下 🙂

**③ 交流想法：开 Discussions** — 开放性话题来这里聊：
- 💬 [Q&A](https://github.com/datawhalechina/deepagents-in-action/discussions/categories/q-a) — 学习中卡住了、概念没搞懂，来这里问
- 🗣️ [General](https://github.com/datawhalechina/deepagents-in-action/discussions/categories/general) — 聊聊 Agent 开发、分享思路、随便聊
- 💡 [Ideas](https://github.com/datawhalechina/deepagents-in-action/discussions/categories/ideas) — 还不成熟的点子，先聊成熟再开 Issue
- 🙌 [Show and tell](https://github.com/datawhalechina/deepagents-in-action/discussions/categories/show-and-tell) — 用 Deep Agents 做了好玩的东西？来晒一晒

**④ 深度共建：提 PR / 加入社区** — 想直接改内容、修代码、补章节，欢迎 Fork 仓库提 PR；也欢迎加入 [Datawhale 开源社区](https://github.com/datawhalechina)一起共建，把这门课——以及更多开源项目——长期做下去。

## 🤝 关于贡献

- 课程更看重**学习热情和反馈意愿**，而不是资历——零基础也欢迎，跟着学就行；
- 有效反馈与 PR 贡献者会登上课程**贡献者墙**，并有机会获赠 LangChain 官方社区（中国）的实体礼品；
- 提问前可以先搜一下，看看是不是已经有人问过啦。

## 🙏 特别鸣谢

- **[Datawhale](https://github.com/datawhalechina) 开源社区** —— 提供内容指导与运营管理支持，让课程得以体系化打磨并触达更多学习者；
- **[硅基流动（SiliconFlow）](https://cloud.siliconflow.cn/i/Fq9zUwPf)** —— 提供模型算力支持，丰富的模型种类与免费的文本、向量模型，让学习者能低门槛跑通课程里的全部示例。

提问是一种贡献，讨论让课程更好。觉得这门课有用，就点个 ⭐ Star、转发给身边同样在做 Agent 的朋友；也欢迎在评论区聊聊你的看法 👇

## 🐳 关于 Datawhale

《Deep Agents 实战》是 Datawhale 开源社区孵化的众多课程之一。

Datawhale 是一个专注 AI 领域的开源学习社区，秉持 “for the learner，和学习者一起成长” 的理念，聚集了一大批高校学生、科研人员与行业开发者。社区在 GitHub 上已沉淀 **200+ 开源项目**、获得近 **3 万**开发者关注，内容覆盖机器学习、深度学习、大模型、数据科学等方向，其中不少是广受欢迎的高星中文教程，帮助了大量学习者从入门走向进阶。

如果这门课对你有帮助，欢迎到 Datawhale 的 GitHub 主页逛逛——那里还有更多免费、可动手、持续更新的开源项目，等你来学、来用、来共建：

- 🐙 GitHub：https://github.com/datawhalechina
- 🌐 官网：https://datawhale.cn

⭐ 点个 Star、转发分享，或挑一个感兴趣的项目参与进来，都是对开源社区最好的支持。
